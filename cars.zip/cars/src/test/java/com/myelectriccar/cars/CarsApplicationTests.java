package com.myelectriccar.cars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
